#ifndef _INC_GLOBALVAR
#define _INC_GLOBALVAR

/////////////////////////////////////////////////////////////////
// Global Vars
//                         
extern int 	g_nRunMode;	// 0 - With computer
						// 1 - Same computer
extern int  g_nSkill;
extern int  g_nStoneNum;
extern BOOL g_bSoundOn;
extern BOOL g_bUserBlack;
extern BOOL g_bChinese;
extern int  g_nTime1;
extern int  g_nTime2;
extern int  g_nTime3;
extern CString g_strName1;
extern CString g_strName2;
extern CString g_strName3;

#endif //!_INC_GLOBALVAR
