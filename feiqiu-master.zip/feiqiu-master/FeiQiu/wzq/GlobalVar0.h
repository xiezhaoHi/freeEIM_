#ifndef _INC_GLOBALVAR0
#define _INC_GLOBALVAR0

/////////////////////////////////////////////////////////////////
// Global Vars
//                         
int 	g_nRunMode;	// 0 - With computer
					// 1 - Same computer

int  g_nSkill = 1;
int  g_nStoneNum = 0;
BOOL g_bSoundOn   = TRUE;
BOOL g_bUserBlack = TRUE;
BOOL g_bChinese   = TRUE;
int  g_nTime1 = 361;
int  g_nTime2 = 361;
int  g_nTime3 = 361;
CString g_strName1 = "Anonymous";
CString g_strName2 = "Anonymous";
CString g_strName3 = "Anonymous";

#endif //!_INC_GLOBALVAR0
